﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace smallCrow
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Таймер запускает анимацию через 5 секунд
            var delayTimer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(5)
            };
            delayTimer.Tick += (s, args) =>
            {
                delayTimer.Stop();
                ShowPopupAnimation();
            };
            delayTimer.Start();
        }

        private void ShowPopupAnimation()
        {
            // Устанавливаем видимость изображения на Visible перед анимацией
            PopupImage.Visibility = Visibility.Visible;

            // Анимация затемнения фона
            var overlayFadeIn = new DoubleAnimation(0, 0.7, TimeSpan.FromSeconds(0.5));
            DarkOverlay.BeginAnimation(OpacityProperty, overlayFadeIn);
            DarkOverlay.IsHitTestVisible = true;

            // Анимация всплытия изображения
            var slideInAnimation = new DoubleAnimation(300, 0, TimeSpan.FromSeconds(0.5), FillBehavior.HoldEnd);
            PopupImage.RenderTransform.BeginAnimation(TranslateTransform.YProperty, slideInAnimation);
        }

        private void MainGrid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Если клик не на изображении, скрываем его
            if (!PopupImage.IsMouseOver)
            {
                HidePopupAnimation();
            }
        }

        private void HidePopupAnimation()
        {
            // Анимация исчезновения затемнения
            var overlayFadeOut = new DoubleAnimation(0.7, 0, TimeSpan.FromSeconds(0.5));
            DarkOverlay.BeginAnimation(OpacityProperty, overlayFadeOut);
            DarkOverlay.IsHitTestVisible = false;

            // Анимация сдвига изображения вниз
            var slideOutAnimation = new DoubleAnimation(0, 300, TimeSpan.FromSeconds(0.5), FillBehavior.HoldEnd);
            PopupImage.RenderTransform.BeginAnimation(TranslateTransform.YProperty, slideOutAnimation);

            // После завершения анимации скрываем изображение
            slideOutAnimation.Completed += (s, args) =>
            {
                PopupImage.Visibility = Visibility.Hidden;
            };
        }
    }
}
