param($installPath, $toolsPath, $package, $project)

$DTE.ItemOperations.Navigate("https://github.com/pvginkel/PdfiumViewer/wiki/Installation-instructions")
